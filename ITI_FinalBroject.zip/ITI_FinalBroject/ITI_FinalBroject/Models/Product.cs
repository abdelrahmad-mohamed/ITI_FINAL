﻿    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;

    namespace ITI_FinalBroject.Models
    {
        public class Product
        {

            [DisplayName("Product ID")]
            public int ProductId { get; set; }

            [Required]
            [DisplayName("Product Name")]
            [MinLength(4 , ErrorMessage = "The word must be greater than 4")]
            public string Title { get; set; }

            [Required]
            [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0")]
            [DisplayName("Product Cost")]
            public decimal Price { get; set; }

            [DisplayName("Product Description")]
            [StringLength(100, ErrorMessage = "The Description must be in range(5 to 100) characters.", MinimumLength = 5)]

            public string Description { get; set; }

            [Required]
            [Range(0, int.MaxValue, ErrorMessage = "Quantity must be positive")]
            [DisplayName("Product Capacity ")]
            public int Quantity { get; set; }

            [DisplayName("Product Image")]
            public string ImagePath { get; set; }

            [DisplayName("Category Id")]
            public int CategoryId { get; set; }
            // Navigation property
            public Category Category { get; set; }
        }
    }

