﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ITI_FinalBroject.Models
{
    public class User
    {
        [DisplayName("User ID")]
        public int UserId { get; set; }



        [Required]
        [StringLength(50, ErrorMessage = "The First Name must be in range(2 to 50) characters.", MinimumLength = 2)]
        [DisplayName("User First Name")]
        public string FirstName { get; set; }



        [Required]
        [StringLength(50, ErrorMessage = "The Last Name must be in range(2 to 50) characters.", MinimumLength = 2)]
        [DisplayName("User Last Name ")]
        public string LastName { get; set; }



        [Required, EmailAddress]
        [DisplayName("User Email")]
        [StringLength(100, ErrorMessage = "The Email must be in range(5 to 100) characters.", MinimumLength = 5)]
        public string Email { get; set; }



        [Required, DataType(DataType.Password)]
        [DisplayName("User Password")]
        public string Password { get; set; }
    }
}