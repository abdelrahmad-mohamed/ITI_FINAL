﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ITI_FinalBroject.Models
{
    public class Category
    {
        [Required]
        [DisplayName("Category Id")]
        public int CategoryId { get; set; }

        [Required]
        [DisplayName("Category Name")]
        public string Name { get; set; }

        [DisplayName("Category Description")]
        public string Description { get; set; }

        public List<Product> Products { get; set; }
    }
}
