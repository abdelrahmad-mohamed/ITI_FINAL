﻿using ITI_FinalBroject.Context;
using ITI_FinalBroject.Models;
using Microsoft.AspNetCore.Mvc;

namespace ITI_FinalBroject.Controllers
{
    public class CategoryController : Controller
    {

        websiteContext db = new websiteContext();


        [HttpGet]
        public IActionResult Index()
        {
            var categories = db.Categories;
            return View(categories);
        }


        public IActionResult Details(int id)
        {
            var category = db.Categories.Find(id);
            if (category == null)
            {
                return RedirectToAction("Index");
            }
            return View(category);
        }
        /*------------------------------------------------------------------*/

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        /*------------------------------------------------------------------*/
        [HttpPost]
        public IActionResult Create(Category category)
        {
            ModelState.Remove("Products");
            if (category != null && ModelState.IsValid )
            {
                db.Categories.Add(category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "All Filled is Required");
            return RedirectToAction("Index");

        }









        /*------------------------------------------------------------------*/
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var Cat = db.Categories.Find(id);
            if (Cat == null)
            {
                return RedirectToAction("Index");
            }
            return View(Cat);
        }
        /*------------------------------------------------------------------*/
        [HttpPost]
        public IActionResult Edit(Category category)
        {
            //// Check URL == Body
            //var Cat = db.Categories.Find(category.CategoryId);
            //if (Cat == null)
            //{
            //    return RedirectToAction("Index");
            //}
            //Cat.Name = category.Name;
            //Cat.Description = category.Description;
            ModelState.Remove("Products");
            if (category != null && ModelState.IsValid)
            {
                db.Categories.Update(category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "All Filled is Required");
            return RedirectToAction("Index");
        }




        /*------------------------------------------------------------------*/

        public IActionResult Delete(int id)
        {
            var Cat = db.Categories.Find(id);
            if (Cat == null)
            {
                return RedirectToAction("Index");
            }
            db.Categories.Remove(Cat);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        /*------------------------------------------------------------------*/
    }
}
