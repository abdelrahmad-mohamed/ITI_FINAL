﻿using ITI_FinalBroject.Context;
using ITI_FinalBroject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;


namespace ITI_FinalBroject.Controllers
{
    public class ProductController : Controller
    {

        websiteContext db = new websiteContext();

        [HttpGet]
        public IActionResult Index()
        {
            var products = db.Products.Include(p => p.Category);
            return View(products);
        }

        public IActionResult Details(int id)
        {
            var product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                return RedirectToAction("Index");
            }
            return View(product);
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product product)
        {
            ModelState.Remove("Products");
            if (product != null && ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                return RedirectToAction("Index");
            }
            ViewBag.Categories = new SelectList(db.Categories, "CategoryId", "Name");
            return View(product);
        }

            [HttpPost]
            public IActionResult Edit(Product product)
            {
                //var oldProduct = db.Products.Find(product.ProductId);
                //if (oldProduct == null)
                //{
                //    return RedirectToAction("Index");
                //}

                //oldProduct.Title = product.Title;
                //oldProduct.Price = product.Price;
                //oldProduct.Description = product.Description;
                //oldProduct.Quantity = product.Quantity;
                //oldProduct.ImagePath = product.ImagePath;
                //oldProduct.CategoryId = product.CategoryId;


                ModelState.Remove("Products");
                if (product != null && ModelState.IsValid)
                {
                    db.Products.Update(product);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ModelState.AddModelError("", "All Filled is Required");
                return RedirectToAction("Index");
            }

        // Delete
        public IActionResult Delete(int id)
        {
            var product = db.Products.Find(id);
            if (product == null)
            {
                return RedirectToAction("Index");
            }
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}