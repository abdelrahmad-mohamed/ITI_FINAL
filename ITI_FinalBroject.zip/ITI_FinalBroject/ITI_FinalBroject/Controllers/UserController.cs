﻿using ITI_FinalBroject.Context;
using ITI_FinalBroject.Models;
using Microsoft.AspNetCore.Mvc;

namespace ITI_FinalBroject.Controllers
{
    public class UserController : Controller
    { 

		websiteContext db = new websiteContext();

		[HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        /*------------------------------------------------------------------*/
        [HttpPost]
        public IActionResult Register(User user)
        {
            if (user != null && ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Login");
            }

            ModelState.AddModelError("", "All Fields Are Required");
            return View(user);
        }

        /*------------------------------------------------------------------*/
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        /*------------------------------------------------------------------*/
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = db.Users.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (user == null)
            {
                ViewBag.Error = "Invalid Email or Password";
                return View();
            }

            return RedirectToAction("Index", "Product");
        }
        /*------------------------------------------------------------------*/

        public IActionResult Logout()
        {
            return RedirectToAction("Login", "User");
        }



    }


}