﻿using ITI_FinalBroject.Models;
using Microsoft.EntityFrameworkCore;

namespace ITI_FinalBroject.Context
{
    public class websiteContext : DbContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-4UELCGL;Database=MVCDay03;Trusted_Connection=True;TrustServerCertificate=true";
            optionsBuilder.UseSqlServer(connectionString);
        }




        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var categories = new List<Category>()
    {
        new Category { CategoryId = 1, Name = "Laptops", Description = "Computing devices" },
        new Category { CategoryId = 2, Name = "Phones", Description = "Smartphones and accessories" },
        new Category { CategoryId = 3, Name = "TVs", Description = "Television and home entertainment" },
        new Category { CategoryId = 4, Name = "Gaming", Description = "Gaming consoles and accessories" },
        new Category { CategoryId = 5, Name = "Appliances", Description = "Home and Kitchen appliances" }
    };

            var products = new List<Product>()
    {
        new Product { ProductId = 1, Title = "HP Laptop", Price = 12000, Quantity = 5, ImagePath = "hp.jpg", Description = "HP EliteBook 840", CategoryId = 1 },
        new Product { ProductId = 2, Title = "Dell XPS", Price = 15000, Quantity = 3, ImagePath = "dell.jpg", Description = "Dell XPS 13", CategoryId = 1 },
        new Product { ProductId = 3, Title = "iPhone 14", Price = 25000, Quantity = 10, ImagePath = "iphone14.jpg", Description = "Apple iPhone 14 Pro", CategoryId = 2 },
        new Product { ProductId = 4, Title = "Samsung Galaxy S23", Price = 22000, Quantity = 8, ImagePath = "samsung.jpg", Description = "Samsung S23 Ultra", CategoryId = 2 },
        new Product { ProductId = 5, Title = "LG OLED TV", Price = 30000, Quantity = 2, ImagePath = "lg_tv.jpg", Description = "LG 55-inch OLED Smart TV", CategoryId = 3 },
        new Product { ProductId = 6, Title = "Sony Bravia", Price = 27000, Quantity = 4, ImagePath = "sony_tv.jpg", Description = "Sony Bravia 4K TV", CategoryId = 3 },
        new Product { ProductId = 7, Title = "PlayStation 5", Price = 18000, Quantity = 6, ImagePath = "ps5.jpg", Description = "Sony PlayStation 5 Console", CategoryId = 4 },
        new Product { ProductId = 8, Title = "Xbox Series X", Price = 17000, Quantity = 5, ImagePath = "xbox.jpg", Description = "Microsoft Xbox Series X", CategoryId = 4 },
        new Product { ProductId = 9, Title = "Air Fryer", Price = 3500, Quantity = 12, ImagePath = "airfryer.jpg", Description = "Tefal Air Fryer", CategoryId = 5 },
        new Product { ProductId = 10, Title = "Microwave", Price = 4000, Quantity = 7, ImagePath = "microwave.jpg", Description = "Samsung Microwave Oven", CategoryId = 5 }
    };

            
            modelBuilder
                .Entity<Category>()
                .HasData(categories);
            
            modelBuilder
                .Entity<Product>()
                .HasData(products);

            base.OnModelCreating(modelBuilder);
        }


        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Category> Categories { get; set; }
    }
}
